package com.example.android.mbm.maindrawer;

/**
 * Created by Allan on 2017-06-11.
 */

public class PersonalModel {
    String City,State,Building,zipcode,Apartment;

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }

    public String getBuilding() {
        return Building;
    }

    public void setBuilding(String building) {
        this.Building = building;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getApartment() {
        return Apartment;
    }

    public void setApartment(String apartment) {
        Apartment = apartment;
    }
}
