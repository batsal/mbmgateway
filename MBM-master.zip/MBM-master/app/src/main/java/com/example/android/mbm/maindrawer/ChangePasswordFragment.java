package com.example.android.mbm.maindrawer;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class ChangePasswordFragment extends Fragment {
    ProgressDialog pd;
    Button changbtn;
    SessionManager sessionManager;
   TextInputEditText oldpass,newpass,confirmpass;
    public static final String KEY_OLDPASSWORD = "old_password";
    public static final String KEY_NEWPASSWORD = "new_password";
    public static final String ID = "user_id";
    private static final String TAG=ChangePasswordFragment.class.getSimpleName();

    public ChangePasswordFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview=inflater.inflate(R.layout.content_password, container, false);
        oldpass=(TextInputEditText) rootview.findViewById(R.id.oldpass);
        newpass=(TextInputEditText)rootview.findViewById(R.id.newpass);
        confirmpass=(TextInputEditText)rootview.findViewById(R.id.confirmpass);
       changbtn=(Button)rootview.findViewById(R.id.changebutton);
        changbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openprofile();
            }
        });
         sessionManager=new SessionManager(getActivity());
        return rootview;
    }
public void openprofile() {
    Log.d("click","click");
    final String oldpas = oldpass.getText().toString().trim();
    final String newpas = newpass.getText().toString().trim();
    final String confirmpas = confirmpass.getText().toString().trim();
    if(oldpas.equals("")&& (newpas.equals(""))&&(confirmpas.equals(""))){
        Toast.makeText(getActivity(),"Enter full Details", Toast.LENGTH_SHORT).show();
    }
   else if (confirmpas.equals(newpas)) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.FORGOT_PASS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response1) {
                        pd.dismiss();
                        Log.d(TAG, response1);
                        // Toast.makeText(getActivity(),response1,Toast.LENGTH_SHORT).show();
                        try {

                            JSONObject jobj1 = new JSONObject(response1);
                            Boolean suc = jobj1.getBoolean("Success");
                            String msg = jobj1.getString("Message");
                            if (suc.equals(false)) {
                                Log.d(TAG, "succesful");
                            }
                            Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            //Log.d(TAG,msg);
                            //  if(msg.equals("Repeated new password do not match."){
                            //      Toast.makeText(getActivity(),msg,Toast.LENGTH_SHORT).show();
                            //}
                        } catch (JSONException e) {

                            e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                //  String credentials = "manish:manish123";
                //  String auth = "Basic YWRtaW46MTIzNA=="
                //         + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                // headers.put("Content-Type", "application/json");
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(ID, String.valueOf(sessionManager.getUser()));
                Log.d("userid",String.valueOf(sessionManager.getUser()));
                params.put(KEY_OLDPASSWORD, oldpas);
                params.put(KEY_NEWPASSWORD, newpas);
                //  params.put(KEY_CONFIRMPASSWORD,confirmpas);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
        pd = new ProgressDialog(getActivity(), R.style.MyAlertDialogStyle);
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
    }
    else
        Toast.makeText(getActivity(),"New password and oldpassowrd doesn't match",Toast.LENGTH_SHORT).show();
}
    }


