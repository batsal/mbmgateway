package com.example.android.mbm.ModelClass;

/**
 * Created by Allan on 2017-06-21.
 */

public class PaymentModel {
    public String getTransdate() {
        return Transdate;
    }

    public void setTransdate(String transdate) {
        Transdate = transdate;
    }

    public String getTransstatus() {
        return Transstatus;
    }

    public void setTransstatus(String transstatus) {
        Transstatus = transstatus;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    String Transdate;
    String Transstatus;
    String description;
}
