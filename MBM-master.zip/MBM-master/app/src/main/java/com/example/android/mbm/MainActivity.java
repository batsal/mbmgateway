package com.example.android.mbm;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.maindrawer.MainActivity3;
import com.example.android.mbm.maindrawer.PersonalFragment;
import com.example.android.mbm.maindrawer.PersonalModel;
import com.example.android.mbm.maindrawer.RegisterFragmentActivity;
import com.example.android.mbm.maindrawer.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String REGISTER_URL = "https://mbmmgt.com/mbm-rest/index.php/api/login";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String TAG = MainActivity.class.getSimpleName();
    PersonalModel pr;
    PersonalFragment obj;
    EditText Password;
    EditText Username;
    String msg;
    ProgressDialog pd;
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button) findViewById(R.id.skipbutton);
        Button btnregister = (Button) findViewById(R.id.btnregisterbutton);
        pr = new PersonalModel();
        obj = new PersonalFragment();
        TextView textView = (TextView) findViewById(R.id.forgot);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Forgotpassword.class);
                startActivity(intent);
            }
        });
        Username = (EditText) findViewById(R.id.username);
        Password = (EditText) findViewById(R.id.password);
        btn.setOnClickListener(this);
        session = new SessionManager(this);
        if (session.isLoggedIn()) {
            // User is already logged in. Take him to main activity
            Intent intent = new Intent(MainActivity.this,
                    MainActivity3.class);
            startActivity(intent);
            finish();
        }

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registeractivity = new Intent(MainActivity.this, RegisterFragmentActivity.class);
                startActivity(registeractivity);

            }
        });
    }

    private void login() {
        pd = new ProgressDialog(MainActivity.this, R.style.MyAlertDialogStyle);
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
        final String uername = Username.getText().toString().trim();
        final String password = Password.getText().toString().trim();
        if ((uername.equals("")) || (password.equals(""))) {
            pd.dismiss();
            Toast.makeText(getApplicationContext(), "Enter username or password", Toast.LENGTH_SHORT).show();
        } else {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d(TAG, response.toString());
                            try {

                                JSONObject jobj = new JSONObject(response);
                                Log.d(TAG, jobj.toString());
                                msg = jobj.getString("Message");

                                Log.d(TAG, msg);
                                Boolean bol = jobj.getBoolean("Success");
                                Log.d(TAG, bol.toString());
                                if (bol.equals(true)) {
                                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                                    session.setLogin(true);
                                    openProfile();
                                } else
                                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                                JSONObject data = jobj.getJSONObject("data");
                                JSONArray jArray = data.getJSONArray("user");
                                JSONObject jsonObject = jArray.getJSONObject(0);
                                Log.d(TAG, jsonObject.toString());
                                String city = jsonObject.getString("city");
                                String state = jsonObject.getString("state");
                                String zipcode = jsonObject.getString("zipcode");
                                String building = jsonObject.getString("building");
                                String apartment = jsonObject.getString("apartment");
                                Integer user = jsonObject.getInt("user_id");
                                String lastname = jsonObject.getString("last_name");
                                String firstname = jsonObject.getString("first_name");
                                String email = jsonObject.getString("email");
                                String phone = jsonObject.getString("phone");

                                session.setCity(city);
                                session.setBuilding(building);
                                session.setApartment(apartment);
                                session.setState(state);
                                session.setZip(zipcode);
                                session.setLastname(lastname);
                                session.setFirstname(firstname);
                                session.setEmal(email);
                                session.setphone(phone);
                                pr.setCity(city);
                                pr.setBuilding(building);
                                session.setUser(user);
                                Log.d(TAG, city);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            pd.dismiss();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            pd.dismiss();

                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                    return headers;
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put(KEY_USERNAME, uername);
                    params.put(KEY_PASSWORD, password);
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }


    }

    public void openProfile() {
        Intent intent = new Intent(MainActivity.this, MainActivity3.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onClick(View view) {
        login();
    }


}
