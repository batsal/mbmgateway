package com.example.android.mbm.maindrawer;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * Created by Allan on 2017-06-04.
 */

public class SessionManager {
    private static String TAG = SessionManager.class.getSimpleName();

    // Shared Preferences
    SharedPreferences pref;

    SharedPreferences.Editor editor;
    Context _context;

    // Shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences file name
    private static final String PREF_NAME = "MBMLogin";
    private static final String FIRSTNAME = "firstname";
    private static final String LASTNAME = "lastname";
    private static final String CITY = "city";
    private static final String STATE = "state";
    private static final String ZIP = "zip";
    private static final String BUILDING = "building";
    private static final String APARTMENT = "apartment";
    private static final String KEY_IS_LOGGEDIN = "isLoggedIn";
    private static final String USER = "user_id";
    private static final String USER_ID = "user_id";
    private static final String EMAL = "email";
    private static final String PHONE = "Phone";
    public SessionManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setLogin(boolean isLoggedIn) {

        editor.putBoolean(KEY_IS_LOGGEDIN, isLoggedIn);

        // commit changes
        editor.commit();
        

        Log.d(TAG, "User login session modified!");
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGEDIN, false);
    }


   public void setCity(String city){
       editor.putString(CITY,city);
        editor.commit();
    }
public String getCity() {
    //  pref.getString(CITY,null);
    return pref.getString(CITY, null);
}
    public void setBuilding(String building){
        editor.putString(BUILDING,building);
        editor.commit();
    }
    public String getBuilding() {
        //  pref.getString(CITY,null);
        return pref.getString(BUILDING, null);

    }
    public void setState(String state){
        editor.putString(STATE,state);
        editor.commit();
    }
    public String getState() {
        //  pref.getString(CITY,null);
        return pref.getString(STATE, null);

    }
    public void setZip(String zip){
        editor.putString(ZIP,zip);
        editor.apply();
    }
    public String getZip() {
        //  pref.getString(CITY,null);
        return pref.getString(ZIP, null);

    }
    public void setApartment(String apart){
        editor.putString(APARTMENT,apart);
        editor.commit();
    }
    public String getApartment() {
        //  pref.getString(CITY,null);
        return pref.getString(APARTMENT, null);

    }
    public void setUser(Integer user ){
        editor.putInt(USER,user);
        editor.commit();
        editor.apply();
    }
    public Integer getUser(){
        return pref.getInt(USER,0);
    }
    public void setFirstname(String firstname){
        editor.putString(FIRSTNAME,firstname);
        editor.commit();
    }
    public String getFirstname() {
        //  pref.getString(CITY,null);
        return pref.getString(FIRSTNAME, null);

    }
    public void setLastname(String lastname){
        editor.putString(LASTNAME,lastname);
        editor.commit();
    }
    public String getLastname() {
        //  pref.getString(CITY,null);
        return pref.getString(LASTNAME, null);

    }
    public String getemail(){

        return pref.getString(EMAL,null);
    }
    public void setEmal(String email){
        editor.putString(EMAL,email);
    }

    public String getphone(){
        return pref.getString(PHONE,null);
    }
    public void setphone(String phone){
        editor.putString(PHONE,phone);
        editor.commit();
        editor.apply();
    }
    public void setid(Integer id ){
        editor.putInt(USER_ID,id);
    }

}


