package com.example.android.mbm.maindrawer;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.AdapterClass.PaymentAdapter;
import com.example.android.mbm.ModelClass.PaymentModel;

import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PaymentFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener  {
    private SwipeRefreshLayout swipeRefreshLayout;
    ProgressDialog pd;
    private static final String TAG = DocumentsFragment.class.getSimpleName();
    JSONArray  Paymentinfo;
    JSONArray  paymentinfo;
    String desc,transdate,status;
    private List<PaymentModel> list = new ArrayList<PaymentModel>();
    PaymentAdapter adapter;
    SessionManager Paysm;
    View vie;
    LinearLayout ll;
    RelativeLayout rr;
    public PaymentFragment(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview=inflater.inflate(R.layout.content_payment_fragment, container, false);
       View view=inflater.inflate(R.layout.dialog,container);
        rr=(RelativeLayout)view.findViewById(R.id.dialog);
        LinearLayout trylayout=(LinearLayout)view.findViewById(R.id.trylayout);

        Paysm= new SessionManager(getContext());
        ListView paymentlist= (ListView)rootview.findViewById(R.id.paymentlistview);
        swipeRefreshLayout = (SwipeRefreshLayout)rootview. findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(this);
        TextView tryagain=(TextView)view.findViewById(R.id.tryagain);
        tryagain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG,"called");
                onRefresh();

            }
        });
        ll=(LinearLayout)rootview.findViewById(R.id.nodatap);
        swipeRefreshLayout.setColorSchemeResources(
                R.color.refresh_progress_1);
        swipeRefreshLayout.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        viewPayment();

                                    }
                                }
        );


        // paymentlist.setCacheColorHint(Color.TRANSPARENT);
         adapter= new PaymentAdapter(getActivity(), list);

    paymentlist.setAdapter(adapter);

        Log.d(TAG,adapter.toString());

        /*
        if (adapter.getCount()==0){
            ll.setVisibility(View.VISIBLE);
        }
        else{
            ll.setVisibility(View.GONE);
        }
*/
        return rootview;
    }
    public  void viewPayment(){
        list.clear();
        swipeRefreshLayout.setRefreshing(true);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.PAYMENT_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d(TAG, response);
                        try {
                            JSONObject jobject = new JSONObject(response);
                            JSONObject data = jobject.getJSONObject("data");
                            Paymentinfo= data.getJSONArray("payment_info");
                            paymentinfo=Paymentinfo.getJSONArray(0);

                            for (int i = 0; i < paymentinfo.length(); i++) {

                                try {
                                    //Getting json object
                                    // JSONObject json = j.getJSONObject(i);

                                    transdate= paymentinfo.getJSONObject(i).getString("transaction_date");
                                    Log.d(TAG, transdate);
                                    status = paymentinfo.getJSONObject(i).getString("transaction_status");
                                    desc=paymentinfo.getJSONObject(i).getString("description");
                                    PaymentModel object = new PaymentModel();
                                    object.setDescription(desc);
                                    object.setTransdate(transdate);
                                    object.setTransstatus(status);
                                    list.add(object);
                             } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                 adapter.notifyDataSetChanged();


                            }

                            swipeRefreshLayout.setRefreshing(false);

                        } catch (JSONException e) {
                            swipeRefreshLayout.setRefreshing(false);
                            e.printStackTrace();

                        }

                        if(list.isEmpty()){
                            rr.setVisibility(View.VISIBLE);

                            Log.d(TAG,list.toString());
                        }
                        else {
                            rr.setVisibility(View.GONE);

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        swipeRefreshLayout.setRefreshing(false);
                        if(list.isEmpty()){
                            adapter.notifyDataSetChanged();
                            rr.setVisibility(View.VISIBLE);

                            Log.d(TAG,list.toString());
                        }
                        else {
                            rr.setVisibility(View.GONE);

                        }
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                //  String credentials = "manish:manish123";
                //  String auth = "Basic YWRtaW46MTIzNA=="
                //         + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                // headers.put("Content-Type", "application/json");
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(Config.USER_ID, String.valueOf(Paysm.getUser()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);

    }

    @Override
    public void onRefresh() {
        viewPayment();
    }
}
