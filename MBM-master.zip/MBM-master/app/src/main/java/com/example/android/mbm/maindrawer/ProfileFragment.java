package com.example.android.mbm.maindrawer;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.EditProfile;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import static android.content.ContentValues.TAG;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment  {
    ProgressDialog pd;
   Integer userid;
    EditText first,last,city,state,zip,phone,building,apartment,email;
    SessionManager smanager;
    private static final String FIRSTNAME = "first_name";
    private static final String LASTNAME = "last_name";
    private static final String CITY = "city";
    private static final String STATE = "state";
    private static final String ZIP = "zipcode";
    private static final String BUILDING = "building";
    private static final String APARTMENT = "apartment";
    private static final String EMAIL = "user_email";
    private static final String USER = "user_id";
    private static final String PHONE = "phone";
    Fragment fragment;
    private static final String USERINFO =  Config.baseUrl + "editInfo";

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview=inflater.inflate(R.layout.content_profile, container, false);
        Button savbtn=(Button) rootview.findViewById(R.id.savebutton);
        Toolbar toolbar = (Toolbar) rootview.findViewById(R.id.toolbar);

        //set toolbar appearance


        //for crate home button
        smanager=new SessionManager(getContext());
        MainActivity3 ob= new MainActivity3();
        first=(EditText) rootview.findViewById(R.id.first);
       last=(EditText)rootview.findViewById(R.id.last);
//         city=(EditText)rootview.findViewById(R.id.city);
//         state=(EditText)rootview.findViewById(R.id.state);
//         zip=(EditText)rootview.findViewById(R.id.zip);
         phone=(EditText)rootview.findViewById(R.id.phone);
//         building=(EditText)rootview.findViewById(R.id.building);
         apartment=(EditText)rootview.findViewById(R.id.apartment);
        email=(EditText)rootview.findViewById(R.id.email);
//        first.setText(smanager.getFirstname());
//        last.setText(smanager.getLastname());
//        city.setText(smanager.getCity());
//        state.setText(smanager.getState());
//        zip.setText(smanager.getZip());
//        phone.setText(smanager.getphone());
//        building.setText(smanager.getBuilding());
//        apartment.setText(smanager.getApartment());
//        email.setText(smanager.getemail());

//        ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
//        if (actionBar != null) {
//            actionBar.setDisplayHomeAsUpEnabled(true);
//
//            actionBar.setDisplayShowTitleEnabled(true);
//        }
        String emailno=smanager.getemail();
      //  String citytext1=smanager.getCity();
     //   String buildingtext=smanager.getBuilding();
        String firstname=smanager.getFirstname();
        String lastname=smanager.getLastname();
        String phonno=smanager.getphone();
        String apartmenttext=smanager.getApartment();
      //  String ziptext1=smanager.getZip();
     //   String statetext1=smanager.getState();
        if(emailno.equals("null")){
            email.setText("");
        }
        else{
            email.setText(emailno);
        }
        if(firstname.equals("null")){
            first.setText("");
        }
        else{
            first.setText(firstname);
        }
        if(lastname.equals("null")){
            last.setText("");
        }
        else{
            last.setText(lastname);
        }
        if(phonno.equals("null")){
            phone.setText("");
        }
        else{
            phone.setText(phonno);
        }
//        if(citytext1.equals("null")){
//            city.setText("");
//        }
//        else{
//            city.setText(citytext1);
//        }
//        // citytext.setText(city);
//        if(buildingtext.equals("null")){
//            building.setText("");
//        }
//        else{
//
//            building.setText(buildingtext);
//        }
//        //buildingtext.setText(building);
//        if(statetext1.equals("null")){
//            state.setText("");
//        }
//        else{
//
//            state.setText(statetext1);
//        }
//        //  statetext.setText(state);
//        if(ziptext1.equals("null")){
//            zip.setText("");
//        }
//        else{
//
//            zip.setText(ziptext1);
//        }
        // zip.setText(zipcode);
        if(apartmenttext.equals("null")){
            apartment.setText("");
        }
        else{

            apartment.setText(apartmenttext);
        }
        savbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveprofile();
//               FragmentManager fm = getFragmentManager();
//                fm.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
//                    @Override
//                    public void onBackStackChanged() {
//
//                    }
//                });
               // FragmentTransaction ft = fm.beginTransaction();
               // PersonalFragment llf = new PersonalFragment();
               // ft.replace(R.id.content_frame, llf);
               // ft.commit();


            }
        });

        return rootview;
    }
public void saveprofile() {
    final String firsname = first.getText().toString().trim();
    final String lastname = last.getText().toString().trim();
    final String emal = email.getText().toString().trim();
    final String Phone = phone.getText().toString().trim();
//    final String State=state.getText().toString();
//    final String City=city.getText().toString().trim();
//    final String Zip=zip.getText().toString().trim();
//    final String Building=building.getText().toString();
    final String Apartment = apartment.getText().toString().trim();
    if ((firsname.equals("")) || (lastname.equals("")) || (emal.equals("")) || (phone.equals("")) || (Apartment.equals(""))) {

        Toast.makeText(getContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
    } else {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.PROFILE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.dismiss();
                        Log.d(TAG, response);
                        //Toast.makeText(getActivity(),response,Toast.LENGTH_SHORT).show();
                        try {

                            JSONObject jobj = new JSONObject(response);
                            Log.d(TAG, jobj.toString());
                            String msg = jobj.getString("Message");
                            Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                            JSONObject data = jobj.getJSONObject("data");
                            JSONArray jArray = data.getJSONArray("user");
                            JSONObject jsonObject = jArray.getJSONObject(0);
                            userid = jsonObject.getInt("user_id");
                            Boolean success = jobj.getBoolean("Success");
                            if (success == true) {
//                            smanager.setState(State);
//                            smanager.setCity(City);
//                            smanager.setZip(Zip);
//                            smanager.setBuilding(Building);
                                smanager.setApartment(Apartment);
                                smanager.setFirstname(firsname);
                                smanager.setLastname(lastname);
                                smanager.setEmal(emal);
                                smanager.setphone(Phone);
                                Intent intent = new Intent(getActivity(), MainActivity3.class);
                                startActivity(intent);
//                            FragmentManager fm = getFragmentManager();
//                            FragmentTransaction ft = fm.beginTransaction();
//                            PersonalFragment personal = new PersonalFragment();
//                            ft.replace(R.id.content_frame1, personal);
//                            ft.addToBackStack(null);
//                            ft.commit();
                            }
                            // SharedPreferences m = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                            // SharedPreferences.Editor editor = m.edit();
                            // editor.putString(NAME, email);
                            // editor.commit();

                            // String mResponse = m.getString(NAME, "");
                            //Log.d(TAG,mResponse);

                        } catch (JSONException e) {

                            e.printStackTrace();

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                //  String credentials = "manish:manish123";
                //  String auth = "Basic YWRtaW46MTIzNA=="
                //         + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                // headers.put("Content-Type", "application/json");
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(FIRSTNAME, firsname);
                params.put(LASTNAME, lastname);
                Log.d("lastname",lastname);
//            params.put(CITY,City);
//            params.put(STATE,State);
//            params.put(ZIP,Zip);
                params.put(EMAIL, emal);
                params.put(PHONE, Phone);
                params.put(APARTMENT, Apartment);
                //   params.put(BUILDING,Building);
                params.put(USER, String.valueOf(smanager.getUser()));
                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
        pd = new ProgressDialog(getActivity(), R.style.MyAlertDialogStyle);
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
    }
}
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {

            case android.R.id.home:
                FragmentManager fm = getFragmentManager();
                if (fm.getBackStackEntryCount() > 0) {
                    fm.popBackStack();
                    onResume();
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onResume() {
        super.onResume();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {


                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    Intent intent=new Intent(getActivity(),MainActivity3.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
//                    PersonalFragment personal = new PersonalFragment();
//                    FragmentManager fragmentManager = getFragmentManager();
//                    ProfileFragment profileFragment=new ProfileFragment();
//                    FragmentTransaction  fragmentTransaction = fragmentManager.beginTransaction();
//                    fragmentTransaction.replace(R.id.content_frame1, personal);
//                    fragmentTransaction.addToBackStack(null);
//                   // fragmentTransaction.remove(profileFragment);
//                    fragmentTransaction.commit();
                    return true;
                }
                return false;
            }
        });
    }

}

