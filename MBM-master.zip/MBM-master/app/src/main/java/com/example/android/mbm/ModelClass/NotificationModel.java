package com.example.android.mbm.ModelClass;

/**
 * Created by Allan on 2017-06-21.
 */

public class NotificationModel {
    String stamp;
    String message;


    public String getStamp() {
        return stamp;
    }

    public void setStamp(String stamp) {
        this.stamp = stamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
