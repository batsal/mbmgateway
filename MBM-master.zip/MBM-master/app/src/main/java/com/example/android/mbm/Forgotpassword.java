package com.example.android.mbm;

import android.app.ProgressDialog;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.maindrawer.SessionManager;
import com.example.android.mbm.Url.Config;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Forgotpassword extends AppCompatActivity {
    ProgressDialog pd;
    private static final String TAG=Forgotpassword.class.getSimpleName();
SessionManager snm;
    String msg,textfield;
    TextInputEditText username;
    private static final String USER = "user";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgotpassword);
        Button dismiss=(Button)findViewById(R.id.dismissbtn);
        Button request=(Button)findViewById(R.id.requestbutton);
        snm=new SessionManager(this);
         username=(TextInputEditText)findViewById(R.id.usernameor);

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                onBackPressed();
            }
        });
        request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usname=username.getText().toString();
                if(usname.equals("")){
                    Toast.makeText(Forgotpassword.this,"Enter username or email",Toast.LENGTH_SHORT).show();
                }
                else
                requestpass();
            }
        });
    }
    public void requestpass(){
        final String user=username.getText().toString().trim();
        pd=new ProgressDialog(Forgotpassword.this, R.style.MyAlertDialogStyle);
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.FORGOT_PASS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.dismiss();
                        Log.d(TAG, response);
                        try {

                            JSONObject jobj = new JSONObject(response);
                            Log.d(TAG, jobj.toString());
                            msg = jobj.getString("Message");
                            Log.d(TAG, msg);
                                Toast.makeText(Forgotpassword.this, msg, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                        Log.e(TAG, error.toString());
                        Toast.makeText(Forgotpassword.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(USER,user);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
