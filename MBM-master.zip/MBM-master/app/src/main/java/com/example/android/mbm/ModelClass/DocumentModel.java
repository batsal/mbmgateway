package com.example.android.mbm.ModelClass;

import android.util.Log;

/**
 * Created by Allan on 2017-06-19.
 */

public class DocumentModel {
    String extension;
    String description;

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
        Log.d("documentlist",extension);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
