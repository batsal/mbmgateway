package com.example.android.mbm.maindrawer;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.v4.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.example.android.mbm.EditProfile;
import com.example.android.mbm.R;
import com.example.android.mbm.Roundedimageview;

/**
 * A simple {@link Fragment} subclass.
 */
public class PersonalFragment extends Fragment {
    PersonalModel pr;
    TextView te;
    SessionManager Personalsm;
    TextView citytext,buildingtext,apartmenttext,zip,statetext;
    SessionManager session;
    public PersonalFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview=inflater.inflate(R.layout.content_personal, container, false);
        Roundedimageview img=(Roundedimageview)rootview.findViewById(R.id.img);
        Glide.with(this).load(R.drawable.profilelogo).into(img);
         citytext=(TextView)rootview.findViewById(R.id.City);
        buildingtext=(TextView)rootview.findViewById(R.id.building);
        statetext=(TextView)rootview.findViewById(R.id.State);
        zip=(TextView)rootview.findViewById(R.id.zipcode);
        TextView firstname=(TextView)rootview.findViewById(R.id.profilefistname);
        TextView lastname=(TextView)rootview.findViewById(R.id.profilelastname);
        TextView email=(TextView)rootview.findViewById(R.id.profileemail);
        TextView phone=(TextView)rootview.findViewById(R.id.profilephone);
        apartmenttext=(TextView)rootview.findViewById(R.id.Apartment);
        pr=new PersonalModel();
       Personalsm=new SessionManager(getContext());
        ImageView imgview=(ImageView)rootview.findViewById(R.id.editicon);
        imgview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), EditProfile.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
//                FragmentManager fm = getFragmentManager();
//                 FragmentTransaction ft = fm.beginTransaction();
//                ProfileFragment llf = new ProfileFragment();
//                 ft.replace(R.id.content_frame, llf);
//                ft.addToBackStack("tag");
//                ft.commit();
            }
        });

        String city=Personalsm.getCity();
        String building=Personalsm.getBuilding();
        Log.d("building",building);
        String state=Personalsm.getState();
        String apartment=Personalsm.getApartment();
        String zipcode=Personalsm.getZip();
        firstname.setText(Personalsm.getFirstname());
        lastname.setText(Personalsm.getLastname());
        email.setText(Personalsm.getemail());
        phone.setText(Personalsm.getphone());
        if(city.equals("null")){
            citytext.setText("");
        }
        else{
            citytext.setText(city);
        }
       // citytext.setText(city);
        if(building.equals("null")){
            buildingtext.setText("");
        }
        else{

            buildingtext.setText(building);
        }
        //buildingtext.setText(building);
        if(state.equals("null")){
            statetext.setText("");
        }
        else{

            statetext.setText(state);
        }
      //  statetext.setText(state);
        if(zipcode.equals("null")){
            zip.setText("");
        }
        else{

            zip.setText(zipcode);
        }
       // zip.setText(zipcode);
        if(apartment.equals("null")){
            apartmenttext.setText("");
        }
        else{

            apartmenttext.setText(apartment);
        }
       // apartmenttext.setText(apartment);
        return rootview;
    }



}
