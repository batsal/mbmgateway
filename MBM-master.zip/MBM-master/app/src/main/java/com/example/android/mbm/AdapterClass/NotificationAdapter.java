package com.example.android.mbm.AdapterClass;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.android.mbm.ModelClass.DocumentModel;
import com.example.android.mbm.ModelClass.NotificationModel;
import com.example.android.mbm.R;

import java.util.List;

/**
 * Created by Allan on 2017-06-21.
 */

public class NotificationAdapter extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<NotificationModel> DataList;
    public NotificationAdapter(Activity activity, List<NotificationModel> dataitem) {
        this.activity = activity;
        this.DataList = dataitem;
    }
    @Override
    public int getCount() {
        return DataList.size();
    }

    @Override
    public Object getItem(int location) {
        return DataList.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            // convertView = inflater.inflate(R.layout.documentlistitem, false);
            convertView=inflater.inflate(R.layout.notificationitem, parent, false);

        TextView message = (TextView) convertView.findViewById(R.id.message);
        TextView stamp= (TextView) convertView.findViewById(R.id.stamp);
        NotificationModel m = DataList.get(position);

        stamp.setText(m.getStamp());
        message.setText(m.getMessage());
        if(position%2==1){
            convertView.setBackgroundColor(Color.parseColor("#f2f2f2"));
        }
        else
            convertView.setBackgroundColor(Color.parseColor("#FFFFFF"));

        return convertView;
    }

}
