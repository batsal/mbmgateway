package com.example.android.mbm.maindrawer;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.AdapterClass.NotificationAdapter;
import com.example.android.mbm.ModelClass.NotificationModel;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;

/**
 * A simple {@link Fragment} subclass.
 */
public class NotificationFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private SwipeRefreshLayout swipeRefreshLayout;
    SessionManager notsm;
    ListView listView;
     NotificationAdapter notificationAdapter;
     JSONArray notification;
     String stamp;
     String message;
    private List<NotificationModel> list = new ArrayList<NotificationModel>();
    private int offSet = 0;
RelativeLayout rr;
    public NotificationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootview = inflater.inflate(R.layout.notification, container, false);
        View view=inflater.inflate(R.layout.dialog,container);
        rr=(RelativeLayout)view.findViewById(R.id.dialog);
        notsm=new SessionManager(getContext());
        listView = (ListView) rootview.findViewById(R.id.notficationlistview);
        notificationAdapter = new NotificationAdapter(getActivity(),list);
        listView.setAdapter(notificationAdapter);

        swipeRefreshLayout = (SwipeRefreshLayout)rootview. findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(
                R.color.refresh_progress_1);
        swipeRefreshLayout.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        viewnotification();
                                    }
                                }
        );
//        viewnotification();
        return rootview;
    }
    public void viewnotification(){
        swipeRefreshLayout.setRefreshing(true);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.NOTIFICATION,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, response);
                        try {

                            JSONObject jobject = new JSONObject(response);
                            JSONObject data = jobject.getJSONObject("data");
                            notification = data.getJSONArray("notifications");
                            NotificationModel object = new NotificationModel();
                            list.clear();
                            for (int i = 0; i < notification.length(); i++) {
                                try {
                                    //Log.d(TAG, "successful motherfucker");
                                    stamp = notification.getJSONObject(i).getString("stamp");
                                    message = notification.getJSONObject(i).getString("message");
                                    object.setMessage(message);
                                    object.setStamp(stamp);
                                    list.add(object);


                                } catch (JSONException e) {
                                  //  swipeRefreshLayout.setRefreshing(false);
                                    e.printStackTrace();
                                }
                                notificationAdapter.notifyDataSetChanged();
                            }
                            swipeRefreshLayout.setRefreshing(false);


                        } catch (JSONException e) {
//                            rr.setVisibility(View.VISIBLE);
                            e.printStackTrace();
                            swipeRefreshLayout.setRefreshing(false);
                        }
                        if(list.isEmpty()){
                            rr.setVisibility(View.VISIBLE);

                            Log.d(TAG,list.toString());
                        }
                        else {
                            rr.setVisibility(View.GONE);

                        }
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        swipeRefreshLayout.setRefreshing(false);
                        notificationAdapter.notifyDataSetChanged();
                        if(list.isEmpty()){
                            rr.setVisibility(View.VISIBLE);

                            Log.d(TAG,list.toString());
                        }
                        else {
                            rr.setVisibility(View.GONE);

                        }

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(Config.USER_ID, String.valueOf(notsm.getUser()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);

}

    @Override
    public void onRefresh() {

        //Log.e("called","called");
        viewnotification();
    }
}
