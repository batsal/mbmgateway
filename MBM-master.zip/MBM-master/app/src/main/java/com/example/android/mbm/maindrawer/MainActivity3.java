package com.example.android.mbm.maindrawer;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.NavUtils;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.AdapterClass.NavigationAdapter;
import com.example.android.mbm.MainActivity;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity3 extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private static final String TAG = MainActivity3.class.getSimpleName();
    SessionManager sessionManager;
    ProgressDialog pd;
    String msg;
    String[] itemname = {"Profile Info", "Pay HOA or rent", "Pay other charges", "Payment", "Documents", "Notification", "Report Maintainance Issues", "Change Password", "Logout"};
    TextView title;
    private String[] mNavigationDrawerItemTitles;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
Integer countn=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        title = (TextView) findViewById(R.id.appbartitle);


        mDrawerLayout = (DrawerLayout) findViewById(R.id.main3_drawer_layout);
        // mDrawerLayout.LayoutParams params=(DrawerLayout.LayoutParams)mDrawerList.getLayoutParams();
        mDrawerList = (ListView) findViewById(R.id.navlistview);
        toolbar.setNavigationIcon(R.drawable.dash);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mDrawerLayout.openDrawer(GravityCompat.START);

            }
        });
        sessionManager = new SessionManager(getApplicationContext());

        NavigationAdapter navigationadapter = new NavigationAdapter(this, R.layout.navlistitem, itemname);
        mDrawerList.setAdapter(navigationadapter);

        Fragment fragment = new PersonalFragment();

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).addToBackStack("tag").commit();

        title.setText("Profile Info");

        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                view.setSelected(true);
                Fragment fragment = null;

                switch (position) {
                    case 0:

                        fragment = new PersonalFragment();
                      title.setText("Profile Info");

                        // getSupportActionBar().setTitle("Profile Info");
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 1:
                       // mDrawerLayout.closeDrawer(GravityCompat.START);
                        fragment = new PaymentActivity();
                        //getSupportActionBar().setTitle("Pay Rent");
                        title.setText(R.string.PayRent);
                        mDrawerLayout.closeDrawer(GravityCompat.START);


                        break;
                    case 2:
                        fragment = new PayOther();
                        title.setText(R.string.PayOther);
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 3:
                        fragment = new PaymentFragment();
                        title.setText("Payment");
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 4:

                        fragment = new DocumentsFragment();
                        title.setText("Documents");
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 5:

                        fragment = new NotificationFragment();
                        title.setText("Notification");
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 6:

                        fragment = new ReportFragment();
                        title.setText("Report");
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 7:
                        fragment = new ChangePasswordFragment();
                        title.setText("Change Password");
                        mDrawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case 8:
                        logout();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).addToBackStack("tag").commit();
                } else {
                    Log.e("MainActivity", "Error in creating fragment");
                }
            }
        });
        if (!sessionManager.isLoggedIn()) {

            logout();
        }

    }


    public void logout() {
        pd = new ProgressDialog(MainActivity3.this, R.style.MyAlertDialogStyle);
        pd.setMessage("logging Out..");
        pd.setCancelable(false);
        pd.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.LOGOUT,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.dismiss();
                        Log.d(TAG, response);
                        // Toast.makeText(MainActivity.this,response.toString(),Toast.LENGTH_SHORT).show();
                        try {

                            JSONObject jobj = new JSONObject(response);
                            Log.d(TAG, jobj.toString());
                            msg = jobj.getString("Message");
                            Log.d(TAG, msg);
                            Boolean bol = jobj.getBoolean("Success");
                            Log.d(TAG, bol.toString());
                            if (bol.equals(true)) {
                                sessionManager.setLogin(false);
                                sessionManager.editor.clear().commit();
                                //Toast.makeText(MainActivity3.this, msg, Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity3.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            } else
                                Toast.makeText(MainActivity3.this, msg, Toast.LENGTH_SHORT).show();

                        } catch (JSONException e) {
                            pd.dismiss();
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                        Log.e(TAG, error.toString());

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(Config.USER_ID, "1");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }

    @Override
    public void onBackPressed() {
//        countn++;
//        Log.d("ca",String.valueOf(countn));
////        if(isTaskRoot()){
////            finish();
////        }
////
//        if (getFragmentManager().getBackStackEntryCount() > 0) {
//            getFragmentManager().popBackStack();
//            getFragmentManager().beginTransaction().commit();
//            Log.d("ca","cal");
//        }        //super.onBackPressed();
//
//        else {
//            //super.onBackPressed();
//
//        }


//
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to quit the Application?");
        builder.setCancelable(false);
        builder.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();
                    }
                }
        );
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }
        );
//
//        AlertDialog alertDialog = builder.create();
//        alertDialog.show();

//        }
//        super.onBackPressed();
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setMessage("Are you sure you want to quit the Application?");
//        builder.setCancelable(false);
//        builder.setPositiveButton(
//                "Ok",
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                        finish();
//                    }
//                }
//        );
//                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        dialog.cancel();
//                    }
//                }
//        );
//
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
//        Log.d("called","called");
//        switch (item.getItemId()) {
//            case android.R.id.home:
//                onBackPressed();
//
//              return true;
//        }
//        return super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent parentIntent = NavUtils.getParentActivityIntent(this);
                parentIntent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(parentIntent);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);

    }

}
