package com.example.android.mbm.maindrawer;


import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.android.mbm.AdapterClass.DocumentsAdapter;
import com.example.android.mbm.ModelClass.DocumentModel;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.Inflater;

/**
 * A simple {@link Fragment} subclass.
 */
public class DocumentsFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private static final String TAG = DocumentsFragment.class.getSimpleName();
    View view;
    SessionManager sm;
    ProgressDialog pd;
    ListView listView;
    String desc, exten;
    DownloadManager downloadmanager;
    JSONArray documents;
    String link;
    DocumentsAdapter adapter;

    Dialog dg;
    private SwipeRefreshLayout swipeRefreshLayout;
    RelativeLayout relativeLayout;
    LinearLayout ll;
    private ArrayList<DocumentModel> list = new ArrayList<DocumentModel>();

    RelativeLayout rr;

    public DocumentsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {

        final View rootview = inflater.inflate(R.layout.content_documents, container, false);
        View view=inflater.inflate(R.layout.dialog,container);
        rr=(RelativeLayout)view.findViewById(R.id.dialog);
        listView = (ListView) rootview.findViewById(R.id.doclistview);
        swipeRefreshLayout = (SwipeRefreshLayout) rootview.findViewById(R.id.swipe_refresh_layout);

        sm = new SessionManager(getContext());
        dg = new Dialog(getContext());
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                getpos(position);
            }
        });

        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(
                R.color.refresh_progress_1);
        swipeRefreshLayout.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        getdocuments();
                                    }
                                }
        );
       adapter = new DocumentsAdapter( getActivity(),list);
        listView.setAdapter(adapter);

        return rootview;
    }

    /*  public void openurl() {
          downloadmanager = (DownloadManager) getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
          //Toast.makeText(getActivity(), "items downloading", Toast.LENGTH_SHORT).show();
          Uri uri=Uri.parse("http://igctech.com.np/clients/mbm/wp-content/uploads/users/8.pdf");
          DownloadManager.Request request=new DownloadManager.Request(uri);
          request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
          Long reference=downloadmanager.enqueue(request);
      }*/
    public void getpos(int position) {
        try {
            JSONObject json = documents.getJSONObject(position);
            link = json.getString("link");
            Log.d(TAG, link);

            // sm.setid(id);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        downloadmanager = (DownloadManager) getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
        //Toast.makeText(getActivity(), "items downloading", Toast.LENGTH_SHORT).show();
        Uri uri = Uri.parse(link);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        Long reference = downloadmanager.enqueue(request);

    }

    public void getdocuments() {
        swipeRefreshLayout.setRefreshing(true);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.DOCUMENTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        swipeRefreshLayout.setRefreshing(false);
                        Log.d(TAG, response);
                        // view.setVisibility(view.GONE);
                        // Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
                        try {

                            JSONObject jobj = new JSONObject(response);
                            JSONObject data = jobj.getJSONObject("data");
                            documents = data.getJSONArray("documents");
                            list.clear();
                            for (int i = 0; i < documents.length(); i++) {
                                try {
                                    //Getting json object
                                    // JSONObject json = j.getJSONObject(i);
                                    desc = documents.getJSONObject(i).getString("description");
                                    Log.d("description", desc);
                                    //list.clear();
                                    exten = documents.getJSONObject(i).getString("extension");
                                    Log.d(TAG, exten);
                                    DocumentModel objectt = new DocumentModel();
                                    objectt.setDescription(desc);
                                    objectt.setExtension(exten);
                                    Log.d("called",objectt.toString());
                                    list.add(objectt);
                                    Log.d("list",list.toString());


                                } catch (JSONException e) {
                                    swipeRefreshLayout.setRefreshing(false);
                                    e.printStackTrace();
                                }

                                adapter.notifyDataSetChanged();

                            }


                        } catch (JSONException e) {
                            swipeRefreshLayout.setRefreshing(false);

                            //view.inflate(getContext(), R.layout.dialog);
                            e.printStackTrace();

                        }
                        if(list.isEmpty()){
                            rr.setVisibility(View.VISIBLE);

                            Log.d(TAG,list.toString());
                        }
                        else {
                            rr.setVisibility(View.GONE);

                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        swipeRefreshLayout.setRefreshing(false);
                        adapter.notifyDataSetChanged();
                        if(list.isEmpty()){
                            rr.setVisibility(View.VISIBLE);

                            Log.d(TAG,list.toString());
                        }
                        else {
                            rr.setVisibility(View.GONE);

                        }
                        //inflater.inflate(R.layout.dialog, false);
                       //  view.inflate(getContext(), R.layout.dialog,);

                    }
                }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                //  String credentials = "manish:manish123";
                //  String auth = "Basic YWRtaW46MTIzNA=="
                //         + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                // headers.put("Content-Type", "application/json");
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(Config.USER_ID, String.valueOf(sm.getUser()));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

    @Override
    public void onRefresh() {

        getdocuments();
    }
}


