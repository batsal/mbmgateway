package com.example.android.mbm.AdapterClass;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.mbm.ModelClass.PaymentModel;
import com.example.android.mbm.R;

import java.util.List;

/**
 * Created by Allan on 2017-06-21.
 */

public class PaymentAdapter extends BaseAdapter {
    private Activity activitypayment;
    private LayoutInflater inflater;
    private List<PaymentModel> PaymentList;
    public PaymentAdapter(Activity activity, List<PaymentModel> dataitem) {
        this.activitypayment = activity;
        this.PaymentList = dataitem;
        Log.d("paylist",dataitem.toString());
    }
    @Override
    public int getCount() {
        return PaymentList.size();
    }

    @Override
    public Object getItem(int location) {
        return PaymentList.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activitypayment
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null)
            convertView = inflater.inflate(R.layout.paymentlistitem, parent, false);


        TextView status = (TextView) convertView.findViewById(R.id.Status);
        TextView date = (TextView) convertView.findViewById(R.id.transdate);
        TextView description = (TextView) convertView.findViewById(R.id.transdescription);
        PaymentModel paym = PaymentList.get(position);

        status.setText(paym.getTransstatus());
        date.setText(paym.getTransdate());
        description.setText(paym.getDescription());
       // Log.d("notpay",PaymentList.toString());
        if(position%2==1){
            convertView.setBackgroundColor(Color.parseColor("#f2f2f2"));
        }
        else
            convertView.setBackgroundColor(Color.parseColor("#FFFFFF"));

        return convertView;
    }
}
