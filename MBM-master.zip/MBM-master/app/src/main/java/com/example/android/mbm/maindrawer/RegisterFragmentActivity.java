package com.example.android.mbm.maindrawer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.MainActivity;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by allan on 7/9/17.
 */

public class RegisterFragmentActivity extends AppCompatActivity implements Spinner.OnItemSelectedListener{

    public static String URL_REGISTER = Config.OPENREGISTER;
    private EditText usernamee, first_name, last_name, emaill, phone_number, state, city, zip_code, building, apartment;
    ProgressDialog pDialog;
    SessionManager sessionManager;
    private static final String TAG = RegisterFragmentActivity.class.getSimpleName();
    private Button btnregister;
    Spinner statesp,citysp,zipsp,buildingsp;
    ArrayAdapter<String> cityadapter,zipadapter,buildingadapter;
    String msg,stat,msgcity,msgzip,msgbuilding,msg1;
    JSONArray jsonArray,cityArray,zipArray,buildingArray;
    JSONObject cityopt,zipcodeopt,buildingopt;
    String username,firstname,lastname,email,phone,statetext,citytext,zip,buildingtext,apartmenttxet;

    private ArrayList<String> ss,cityss,zipss,buildingss;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        usernamee = (EditText) findViewById(R.id.txtusername);
        first_name = (EditText) findViewById(R.id.firstname);
        last_name = (EditText) findViewById(R.id.last_name);
        emaill = (EditText) findViewById(R.id.emailll);
        phone_number = (EditText) findViewById(R.id.phone_number);
      //state = (EditText) findViewById(R.id.stateee);
        //city = (EditText) findViewById(R.id.cityyy);
       // zip_code = (EditText) findViewById(R.id.zipppp);
       // building = (EditText) findViewById(R.id.buildinggg);
        apartment = (EditText) findViewById(R.id.apartmenttt);
        btnregister = (Button) findViewById(R.id.savebutton);
        statesp=(Spinner)findViewById(R.id.spinnerstae);
        citysp=(Spinner)findViewById(R.id.spinnercity);
        zipsp=(Spinner)findViewById(R.id.spinnerzip);
        buildingsp=(Spinner)findViewById(R.id.spinnerbuilding);
        // Progress dialog
        statesp.setOnItemSelectedListener(this);
        citysp.setOnItemSelectedListener(this);
        zipsp.setOnItemSelectedListener(this);
        buildingsp.setOnItemSelectedListener(this);
        pDialog = new ProgressDialog(this,R.style.MyAlertDialogStyle);
        pDialog.setCancelable(false);
        ss = new ArrayList<String>();
        cityss=new ArrayList<String>();
        zipss=new ArrayList<String>();
        buildingss=new ArrayList<String>();
       // buildingss=new ArrayList<String>();
// Apply the adapter to the spinner

        // Session manager
        sessionManager = new SessionManager(getApplicationContext());

            login();

        // Register Button Click event
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = usernamee.getText().toString().trim();
               firstname = first_name.getText().toString().trim();
                lastname = last_name.getText().toString().trim();
                email= emaill.getText().toString().trim();
                phone = phone_number.getText().toString().trim();
                apartmenttxet = apartment.getText().toString().trim();

                if (!username.isEmpty() && !firstname.isEmpty() && !lastname.isEmpty()
                        && !email.isEmpty() && !phone.isEmpty() && !apartmenttxet.isEmpty())

                {
                    registerUser();

                } else {

                    Toast.makeText(getApplicationContext(),
                            "Please enter your details!", Toast.LENGTH_LONG)
                            .show();
                }
            }
        });

    }

    private void registerUser() {
        // Tag used to cancel the request
        String tag_string_req = "req_register";

        pDialog.setMessage("Registering ...");
        pDialog.show();

        StringRequest strReq = new StringRequest(Request.Method.POST,
                Config.OPENREGISTER, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d(TAG, "Register Response: " + response.toString());
                pDialog.dismiss();

                try {
                    JSONObject jObj = new JSONObject(response);
                    Log.d(TAG,response);
                   // Toast.makeText(RegisterFragmentActivity.this,response,Toast.LENGTH_SHORT).show();
                    msg1 = jObj.getString("Message");
                    boolean success = jObj.getBoolean("Success");
                    if (success==true) {


                        Toast.makeText(getApplicationContext(), msg1, Toast.LENGTH_SHORT).show();

                        // Launch login activity
                        Intent intent = new Intent(
                                RegisterFragmentActivity.this,
                                MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {


                        Toast.makeText(getApplicationContext(),
                                msg1, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    pDialog.dismiss();
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Registration Error: " + error.getMessage());
                pDialog.dismiss();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                // Posting params to register url

                Map<String, String> params = new HashMap<String, String>();

                params.put("state", stat);
                Log.d(TAG,stat);
                params.put("apartment",apartmenttxet );
                Log.d(TAG,apartmenttxet);
                params.put("city", msgcity);
                Log.d(TAG,msgcity);
                params.put("zipcode", msgzip);
                Log.d(TAG,msgzip);
                params.put("building", msgbuilding);
                Log.d(TAG,msgbuilding);
                params.put("first_name", firstname);
                Log.d(TAG,firstname);
                params.put("last_name", lastname);
                Log.d(TAG,lastname);
                params.put("username", username);
                Log.d(TAG,username);
                params.put("user_email", email);
                Log.d(TAG,email);
                params.put("password", "password");
                params.put("phone",phone);
                Log.d(TAG,phone);

                return params;

            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        requestQueue.add(strReq);
    }
    private void login() {


            StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.OPENREGISTER,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d(TAG, response.toString());
                            try {

                                JSONObject jobj = new JSONObject(response);
                                Log.d(TAG, jobj.toString());
                                msg = jobj.getString("Message");
                                JSONObject data = jobj.getJSONObject("data");
                                 jsonArray=data.getJSONArray("state_option");
                                cityopt=data.getJSONObject("city_option");
                                zipcodeopt=data.getJSONObject("zipcode_option");
                                buildingopt=data.getJSONObject("building_option");
                                Log.d(TAG,buildingopt.toString());
                               // jsonArray1=cityopt.getJSONArray(stat);
                              //  Log.d(TAG,jsonArray1.toString());

                               // JSONArray jsonArray1=data.getJSONArray(ss);
                                getarray(jsonArray);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {


                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                    return headers;
                }
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }

public void getarray(JSONArray array){
    for(int i=0;i<array.length();i++){
        try {
            //Getting json object
            ss.add(array.optString(i));
            //ss=array.getString(i);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Setting adapter to show the items in the spinner
    statesp.setAdapter(new ArrayAdapter<String>(RegisterFragmentActivity.this, R.layout.spinner_item,ss));
   // citysp.setAdapter(new ArrayAdapter<String>(RegisterFragmentActivity.this, R.layout.spinner_item,jsonArray1));

}

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId())
        {
            case R.id.spinnerstae:
                getstate(position);
                try {
                    cityArray = cityopt.getJSONArray(stat);
                    Log.d(TAG,cityArray.toString());
                    getCityArray(cityArray);

                } catch (JSONException e) {

                }
                break;
            case R.id.spinnercity:
                getCity(position);
                try{
                    zipArray=zipcodeopt.getJSONArray(msgcity);
                    getzipArray(zipArray);
                }catch (JSONException e){

                }
              break;

            case R.id.spinnerzip:
                getZip(position);
                try{
                buildingArray=buildingopt.getJSONArray(msgzip);
                    Log.d(TAG,buildingArray.toString());
                    getbuilding(buildingArray);

        }catch (JSONException e) {
            e.printStackTrace();
        }

                break;

            case R.id.spinnerbuilding:
                getBuilding(position);
                break;

        }

    }

    private void getBuilding(int position) {
        try{
            msgbuilding=buildingArray.getString(position);
            Log.d(TAG,msgbuilding);
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getbuilding(JSONArray buildingArray) {
        buildingss.clear();
        for (int i = 0; i < buildingArray.length(); i++) {
            try {

                //Getting json object
                buildingss.add(buildingArray.optString(i));
                Log.d(TAG, buildingss.toString());
                //ss=array.getString(i);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        buildingadapter =(new ArrayAdapter<String>(RegisterFragmentActivity.this, R.layout.spinner_item,buildingss));
        buildingsp.setAdapter(buildingadapter);
        buildingadapter.notifyDataSetChanged();
    }

    private void getZip(int position) {
        try{
            msgzip=zipArray.getString(position);
            Log.d(TAG,msgzip);
        }catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getzipArray(JSONArray zipArray) {
        zipss.clear();
        for (int i = 0; i < zipArray.length(); i++) {
            try {

                //Getting json object
                zipss.add(zipArray.optString(i));
                Log.d(TAG, zipss.toString());
                //ss=array.getString(i);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        zipadapter =(new ArrayAdapter<String>(RegisterFragmentActivity.this, R.layout.spinner_item,zipss));
        zipsp.setAdapter(zipadapter);
        zipadapter.notifyDataSetChanged();

    }

    private void getCity(int position) {
        try{
            msgcity=cityArray.getString(position);
            Log.d(TAG,msgcity);
        }catch (JSONException e){
            e.printStackTrace();
        }
        }



    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast.makeText(this,"Please Enter Details",Toast.LENGTH_SHORT).show();

    }
    public String getstate(int position){


        try {
            stat=jsonArray.getString(position);
            Log.d(TAG,stat);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return stat;
    }
    private void getCityArray(JSONArray cityarray){
        cityss.clear();
        for(int i=0;i<cityarray.length();i++){
            try {

                //Getting json object
                cityss.add(cityarray.optString(i));
                Log.d(TAG,cityss.toString());
                //ss=array.getString(i);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

         cityadapter=(new ArrayAdapter<String>(RegisterFragmentActivity.this, R.layout.spinner_item,cityss));
        citysp.setAdapter(cityadapter);
        cityadapter.notifyDataSetChanged();
    }
}

