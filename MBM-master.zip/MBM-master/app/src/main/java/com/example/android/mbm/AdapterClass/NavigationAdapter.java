package com.example.android.mbm.AdapterClass;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.android.mbm.R;

/**
 * Created by Allan on 2017-06-25.
 */

public class NavigationAdapter extends ArrayAdapter<String> {
    private final Activity context;
    private final String[] Profiletext;


    public NavigationAdapter(Activity context,int resources, String[] itemname) {
        super(context, R.layout.navlistitem, itemname);
        this.context = context;
        this.Profiletext = itemname;

    }
    public View getView(int position, View view, ViewGroup parent) {

        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.navlistitem, null,true);
        TextView profile= (TextView) rowView.findViewById(R.id.itemprofile);
        profile.setText(Profiletext[position]);
        return rowView;

    }
}
