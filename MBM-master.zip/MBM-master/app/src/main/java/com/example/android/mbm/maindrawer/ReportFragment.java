package com.example.android.mbm.maindrawer;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class ReportFragment extends Fragment implements AdapterView.OnItemSelectedListener {
    ProfileFragment PF;
String sendid;
    ReportFragment RF;
    String id;
     String addid;
    AutoCompleteTextView message;
    String addressid;
    SessionManager sm;
    ProgressDialog pd;
    private JSONArray array;
    private ArrayList<String> categories;
    private ArrayList<String> ids;
    Spinner spinner;
    Integer userid;
    Button sendbtn;
    EditText building;
    String reportmsg;
    private static final String ADDRESS_ID="address_id";
    private static final String MESSAGE="message";
    private static final String CATEGORY_ID="category_id";
    private static final String TAG=ReportFragment.class.getSimpleName();
    public ReportFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootview=inflater.inflate(R.layout.content_report, container, false);
        spinner = (Spinner)rootview. findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);
        building=(EditText)rootview.findViewById(R.id.buildingreport);
        sendbtn=(Button)rootview.findViewById(R.id.sendbtn);
        categories = new ArrayList<String>();
        ids=new ArrayList<String>();
        message=(AutoCompleteTextView)rootview.findViewById(R.id.autocomplete);
        sm=new SessionManager(getActivity());
        PF=new ProfileFragment();
        getdata();
        SessionManager sm=new SessionManager(getContext());
String build= sm.getBuilding();
        if(build.equals("null")){
            building.setText("");
        }
        else{
            building.setText(build);
        }
      //  building.setText();
       // ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
      //          R.array.category, R.layout.spinner_item);
      //  adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
     //   spinner.setAdapter(adapter);
        sendbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendReports();
            }
        });
        return rootview;
    }

    public void getdata(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST,Config.DATA_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.dismiss();
                        try {
                            //Parsing the fetched Json String to JSON Object
                           JSONObject j = new JSONObject(response);
                            Log.d(TAG,response);
                            JSONObject data=j.getJSONObject("data");
                            addressid =data.getString("address_id");
                            Log.d(TAG,addressid);
                           String address=data.getString("address");
                            Log.d(TAG,address);
                            userid=data.getInt("user_id");
                           // sm.setid(userid);
                            Log.d(TAG,userid.toString());
                            array=data.getJSONArray(Config.TICKET_CATEGORIES);

                            JSONObject obj=array.getJSONObject(0);
                            sendid=obj.getString("id");
                            Log.d(TAG,sendid);
                            Log.d(TAG,array.toString());
                           // building.setText(address);
                            //Storing the Array of JSON String to our JSON Array
                            //array = j.getJSONArray(Config.JSON_ARRAY);

                            //Calling method getStudents to get the students from the JSON Array
                            getCategories(array);
                        } catch (JSONException e) {
                            pd.dismiss();
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                    }

                })
        {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
            HashMap<String, String> headers = new HashMap<>();
            //  String credentials = "manish:manish123";
            //  String auth = "Basic YWRtaW46MTIzNA=="
            //         + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
            // headers.put("Content-Type", "application/json");
            headers.put("Authorization","Basic YWRtaW46MTIzNA==" );
            return headers;
        }
            @Override
            protected Map<String,String> getParams(){
            Map<String,String> params = new HashMap<String, String>();
            params.put(Config.USER_ID,String.valueOf(sm.getUser()));
            return params;
        }
        };

        //Creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());

        //Adding request to the queue
        requestQueue.add(stringRequest);
        pd=new ProgressDialog(getActivity(), R.style.MyAlertDialogStyle);
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
    }


    private void getCategories(JSONArray array){
        //Traversing through all the items in the json array
        for(int i=0;i<array.length();i++){
            try {
                //Getting json object
                JSONObject json = array.getJSONObject(i);
                 id = array.getJSONObject(i).getString("id");

               // ids.add(id);
               // Log.d(TAG,json.getString(Config.CATEGORIES));
               // ids.add(json.optString(Config.ID));
                //Adding the name of the student to array list
                categories.add(json.optString(Config.CATEGORIES));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //Setting adapter to show the items in the spinner
        spinner.setAdapter(new ArrayAdapter<String>(getContext(), R.layout.spinner_item, categories));

    }
  public String getSession(int position){


        try {
            JSONObject json = array.getJSONObject(position);
             addid= json.getString(Config.ID);
            Log.d(TAG,addid);
           // sm.setid(id);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return addid;
    }

    public void sendReports(){
        reportmsg=message.getText().toString();
        pd=new ProgressDialog(getActivity(), R.style.MyAlertDialogStyle);
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
        if(reportmsg.equals("")){
            pd.dismiss();
            Toast.makeText(getContext(),"Message can't be blank",Toast.LENGTH_SHORT).show();
        }
        else {
            // message=new AutoCompleteTextView(getActivity());
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.RM,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            pd.dismiss();
                            try {
                                JSONObject j = new JSONObject(response);
                                String msg = j.getString("Message");
                                Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                                Boolean suc=j.getBoolean("Success");
                                if(suc.equals(true)){
                                    Intent intent=new Intent(getActivity(),MainActivity3.class);
                                    startActivity(intent);
                                }
                                Log.d(TAG, msg);
                            } catch (JSONException e) {

                                e.printStackTrace();

                            }


                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            pd.dismiss();
                        }
                    }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<>();
                    //  String credentials = "manish:manish123";
                    //  String auth = "Basic YWRtaW46MTIzNA=="
                    //         + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
                    // headers.put("Content-Type", "application/json");
                    headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                    return headers;
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put(Config.USER_ID, String.valueOf(sm.getUser()));
                    // params.put(Config.USER_ID,String.valueOf(userid));
                    params.put(ADDRESS_ID, addressid);
                    params.put(MESSAGE, reportmsg);
                    // params.put(CATEGORY_ID,String.valueOf(sm.getid()));
                    params.put(CATEGORY_ID, addid);
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(getContext());
            requestQueue.add(stringRequest);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id2) {
       getSession(position);

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    }


    //Method to get student name of a particular position




