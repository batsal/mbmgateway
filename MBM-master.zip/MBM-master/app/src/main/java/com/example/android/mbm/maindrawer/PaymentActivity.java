package com.example.android.mbm.maindrawer;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.android.mbm.R;
import com.example.android.mbm.Url.Config;

import net.authorize.acceptsdk.AcceptSDKApiClient;
import net.authorize.acceptsdk.datamodel.common.Message;
import net.authorize.acceptsdk.datamodel.merchant.ClientKeyBasedMerchantAuthentication;
import net.authorize.acceptsdk.datamodel.transaction.CardData;
import net.authorize.acceptsdk.datamodel.transaction.EncryptTransactionObject;
import net.authorize.acceptsdk.datamodel.transaction.TransactionObject;
import net.authorize.acceptsdk.datamodel.transaction.TransactionType;
import net.authorize.acceptsdk.datamodel.transaction.callbacks.EncryptTransactionCallback;
import net.authorize.acceptsdk.datamodel.transaction.response.EncryptTransactionResponse;
import net.authorize.acceptsdk.datamodel.transaction.response.ErrorTransactionResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

//import com.example.android.mbm.R;
//import com.example.android.mbm.Url.Config;

public class PaymentActivity extends Fragment implements View.OnClickListener, EncryptTransactionCallback, Spinner.OnItemSelectedListener {

    public static final String TAG = "CheckoutFragment";
    /**
     * Api ko kaam ko declear
     **/
    private static final String ECHECKTYPE = "echeck_echecktype";
    private static final String EACTYPE = "echeck_accttype";
    private static final String DATA_VALUE = "data_value";
    private static final String FIRSTNAME = "first_name";
    private static final String LASTNAME = "last_name";
    private static final String ADDRESS = "address";
    private static final String CITY = "city";
    private static final String STATE = "state";
    private static final String ZIP = "zip";
    private static final String COUNTRY = "country";
    private static final String AMOUNT = "amount";
    private static final String PAY_FOR = "pay_for";
    private static final String YEAR = "year";
    private static final String MONTH = "month";
    private static final String EXP_DATE_MONTH = "exp_date_month";
    private static final String EXP_DATE_YEAR = "exp_date_year";
    private static final String CARD_NUM = "card_num";
    private static final String TYPE_P = "type_p";
    private static final String USER_ID = "user_id";
    private static final String EMAIL = "email";
    private static final String ABA_ROUTING_NUMBER = "echeck_aba";
    private static final String ECHECK_ACCOUNT_NUMBER = "echeck_account";
    private static final String BANK_NAME = "echeck_bankname";
    private static final String ECHECK_ACCOUNT_NAME = "echeck_bankacctname";
    private static final String ACCOUNT_TYPE = "echeck_accttype";
    private static final String ECHECK_TYPE = "echeck_echecktype";
    private final String CARD_NUMBER = "4111111111111111";
    private final String EXPIRATION_MONTH = "11";
    private final String EXPIRATION_YEAR = "2017";
    private final String CVV = "256";
    private final String POSTAL_CODE = "98001";
    private final String CLIENT_KEY =
            "4Cq2n8KsGj47bP9Exejd7rKTkTq85M2CqDCM9XB25EnuM3c8X4JK8923yDYLdks7";
    // replace with your CLIENT KEY
    private final String API_LOGIN_ID = "3tWJ3z3J"; // replace with your API LOGIN_ID
    private final int MIN_CARD_NUMBER_LENGTH = 13;
    private final int MIN_YEAR_LENGTH = 2;
    private final int MIN_CVV_LENGTH = 3;
    private final String YEAR_PREFIX = "20";
    SessionManager snm;
    EditText paymentAmount, paymentDateMonth, paymentDateYear, creditCardNumber, expiryDateMonth,
            expirydateYear, ccv, firstName, lastName, address, city, state, zipCode, county,
            abaRoutingNumber, accountNumber, bankName, accountName, accountType, echeckType, totalpayment;
    Button btncreditcard, btnecheck;
    String payfor;
    RadioGroup radioGroup1;
    ProgressDialog pd;
    /**
     * Api ko kaam ya bata banda
     **/

    Spinner checktype, accounttype;
    double rate, finalpaymentresult, finalresult;
    private Button checkoutButton;
    private EditText cardNumberView, echeckcardNumberView;
    private EditText monthView;
    private EditText yearView;
    private EditText cvvView;
    private ProgressDialog progressDialog;
    private RelativeLayout responseLayout;
    private TextView responseTitle;
    private TextView responseValue;
    private String cardNumber, cardnumberEcheck;
    private String month, echeckaccountnumber, echeckbankname, echeckaccountname;
    private String year, onesp, twosp;
    private String cvv;
    private AcceptSDKApiClient apiClient;

    //ArrayList<EcheckSpinnerActivity> echecktypee = new ArrayList<>();
    //ArrayList<EcheckSpinnerActivity> accounttypee = new ArrayList<>();
    //ArrayAdapter<EcheckSpinnerActivity> echecktypeadaptor;
    //ArrayAdapter<EcheckSpinnerActivity> accounttypeadaptor;
    private String[] arrayspinnerechecktypee, arrayspinneraccounttype;


    public PaymentActivity() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        snm = new SessionManager(getActivity());
    /*
       build an Accept SDK Api client to make API calls.
       parameters:
         1) Context - current context
         2) AcceptSDKApiClient.Environment - Authorize.net ENVIRONMENT
    */


        try {
            apiClient = new AcceptSDKApiClient.Builder(getActivity(),
                    AcceptSDKApiClient.Environment.PRODUCTION).connectionTimeout(
                    4000) // optional connection time out in milliseconds
                    .build();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }


    }


    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootview = inflater.inflate(R.layout.activity_payment3, container, false);
        initialize(rootview);


        checktype = (Spinner) rootview.findViewById(R.id.echecktype);
        accounttype = (Spinner) rootview.findViewById(R.id.accountype);

        checktype.setOnItemSelectedListener(this);
        accounttype.setOnItemSelectedListener(this);

        //echeck spinner ko vitra ko items
        this.arrayspinnerechecktypee = new String[]{
                "WEB", "PPD", "CCD", "TEL", "ARC", "BOC"

        };

        ArrayAdapter<String> echecktypeadaptor = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, arrayspinnerechecktypee);
        checktype.setAdapter(echecktypeadaptor);


        //accounttype ko spinner
        this.arrayspinneraccounttype = new String[]{
                "checking", "savings", "businessChecking"

        };

        ArrayAdapter<String> accounttypeadaptor = new ArrayAdapter<String>(getContext(), R.layout.spinner_item, arrayspinneraccounttype);

        accounttype.setAdapter(accounttypeadaptor);


        paymentAmount = (EditText) rootview.findViewById(R.id.txtpaymentamount);
        paymentDateMonth = (EditText) rootview.findViewById(R.id.txtpaymentmonth);
        paymentDateYear = (EditText) rootview.findViewById(R.id.txtpaymentyear);


        creditCardNumber = (EditText) rootview.findViewById(R.id.txtcreaditcardnumber);
        expiryDateMonth = (EditText) rootview.findViewById(R.id.txtexpirymonth);
        expirydateYear = (EditText) rootview.findViewById(R.id.txtexpiryyear);
        ccv = (EditText) rootview.findViewById(R.id.txtccv);
        firstName = (EditText) rootview.findViewById(R.id.txtfirstname);
        lastName = (EditText) rootview.findViewById(R.id.txtlname);
        address = (EditText) rootview.findViewById(R.id.txtaddress);
        city = (EditText) rootview.findViewById(R.id.txtcity);
        state = (EditText) rootview.findViewById(R.id.txtstate);
        zipCode = (EditText) rootview.findViewById(R.id.txtzipcode);
        county = (EditText) rootview.findViewById(R.id.txtcountry);
        totalpayment = (EditText) rootview.findViewById(R.id.txttotalpaymentamount);
        final LinearLayout credit = (LinearLayout) rootview.findViewById(R.id.credicard);
        final LinearLayout check = (LinearLayout) rootview.findViewById(R.id.check);
        abaRoutingNumber = (EditText) rootview.findViewById(R.id.txtabaroutingnumber);
        accountNumber = (EditText) rootview.findViewById(R.id.txtaccountnumber);
        bankName = (EditText) rootview.findViewById(R.id.txtbankname);
        accountName = (EditText) rootview.findViewById(R.id.txtaccountname);
        accountType = (EditText) rootview.findViewById(R.id.txtaccounttype);
        echeckType = (EditText) rootview.findViewById(R.id.txtechecktype);

        //buttons
        btncreditcard = (Button) rootview.findViewById(R.id.btncreditcard);
        btnecheck = (Button) rootview.findViewById(R.id.btnecheck);
        btnecheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!echeckareFormDetailsValid()) return;


                try {
                    saveEcheckCardInfo();
//                    progressDialog.dismiss();
                } catch (NullPointerException e) {
                    // Handle exception transactionObject or callback is null.
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();

                    e.printStackTrace();
                }


            }
        });

        radioGroup1 = (RadioGroup) rootview.findViewById(R.id.radioGroup1);

//        final LinearLayout linearLayout = (LinearLayout) rootview.findViewById(R.id.creditcard_layout);
//        linearLayout.setVisibility(LinearLayout.GONE);
//
//        final LinearLayout linearLayout2 = (LinearLayout) rootview.findViewById(R.id.echeck_layout);
//        linearLayout2.setVisibility(LinearLayout.GONE);
//
//        final LinearLayout textviewlayout = (LinearLayout) rootview.findViewById(R.id.weacceptlayout);
//        textviewlayout.setVisibility(LinearLayout.GONE);
//
//        final LinearLayout discovercardlayout = (LinearLayout) rootview.findViewById(R.id.discoverlayout);
//        discovercardlayout.setVisibility(LinearLayout.GONE);
//
//        final LinearLayout authorizelayout = (LinearLayout) rootview.findViewById(R.id.authorizelayout);
//        authorizelayout.setVisibility(LinearLayout.GONE);
//
//        //echeck
//        final LinearLayout echeckauthorizelayout = (LinearLayout) rootview.findViewById(R.id.echeckauthorizelayout);
//        echeckauthorizelayout.setVisibility(LinearLayout.GONE);
//
//        final LinearLayout echeckdiscoverelayout = (LinearLayout) rootview.findViewById(R.id.echeckdiscoverlayout);
//        echeckdiscoverelayout.setVisibility(LinearLayout.GONE);
//
//        final LinearLayout echecktextlayout = (LinearLayout) rootview.findViewById(R.id.echecktextciewlayout);
//        echecktextlayout.setVisibility(LinearLayout.GONE);
//


        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                if (checkedId == R.id.rdocreditcard) {
                    // openDialogPublicPrivateRoom();

                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage("When paying with credit card you will be charged with a 2.5% fee. Is this OK?");
                    builder.setCancelable(false);

                    builder.setPositiveButton(
                            "Ok",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    dialog.cancel();

                                    credit.setVisibility(View.VISIBLE);
                                    check.setVisibility(View.GONE);

//                                    linearLayout.setVisibility(View.VISIBLE);
//                                    linearLayout2.setVisibility(View.GONE);
//                                    btncreditcard.setVisibility(View.VISIBLE);
//                                    btnecheck.setVisibility(View.GONE);
//                                    textviewlayout.setVisibility(View.VISIBLE);
//                                    discovercardlayout.setVisibility(View.VISIBLE);
//                                    authorizelayout.setVisibility(View.VISIBLE);
//
//                                    //echeck conditions for image
//
//                                    echeckauthorizelayout.setVisibility(View.GONE);
//                                    echeckdiscoverelayout.setVisibility(View.GONE);
//                                    echecktextlayout.setVisibility(View.GONE);

//
//                                    try {
//                                        String paymentamount = paymentAmount.getText().toString().trim();
//                                        rate = 2.5;
//                                        //finalpaymentresult = Double.parseDouble((paymentamount));
//                                        finalpaymentresult = Double.parseDouble((paymentamount));
//                                        finalresult = (int) ((rate/100)*finalpaymentresult+finalpaymentresult);
//                                        totalpayment.setText(String.valueOf(finalresult));
//
//
//                                    }catch (NumberFormatException e)
//                                    {
//                                        finalpaymentresult = 0;
//
//                                    }
                                    try {
                                        String paymentamount = paymentAmount.getText().toString().trim();
                                        rate = 2.5;
                                        //finalpaymentresult = Double.parseDouble((paymentamount));
                                        finalpaymentresult = Double.parseDouble((paymentamount));
                                        finalresult = (((0.025) * finalpaymentresult) + finalpaymentresult);
                                        totalpayment.setText(String.valueOf(finalresult));


                                    } catch (NumberFormatException e) {
                                        finalpaymentresult = 0;

                                    }

                                    paymentAmount.addTextChangedListener(new TextWatcher() {
                                        @Override
                                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                                            try {
                                                String paymentamount = paymentAmount.getText().toString().trim();
                                                rate = 2.5;
                                                //finalpaymentresult = Double.parseDouble((paymentamount));
                                                finalpaymentresult = Double.parseDouble((paymentamount));
                                                finalresult = (((0.025) * finalpaymentresult) + finalpaymentresult);
                                                totalpayment.setText(String.valueOf(finalresult));


                                            } catch (NumberFormatException e) {
                                                finalpaymentresult = 0;

                                            }

                                        }

                                        @Override
                                        public void onTextChanged(CharSequence s, int start, int before, int count) {

                                            try {
                                                String paymentamount = paymentAmount.getText().toString().trim();
                                                rate = 2.5;
                                                //finalpaymentresult = Double.parseDouble((paymentamount));
                                                finalpaymentresult = Double.parseDouble((paymentamount));
                                                finalresult = (((0.025) * finalpaymentresult) + finalpaymentresult);
                                                totalpayment.setText(String.valueOf(finalresult));


                                            } catch (NumberFormatException e) {
                                                finalpaymentresult = 0;

                                            }


                                        }

                                        @Override
                                        public void afterTextChanged(Editable s) {
                                            try {
                                                String paymentamount = paymentAmount.getText().toString().trim();
                                                rate = 2.5;
                                                //finalpaymentresult = Double.parseDouble((paymentamount));
                                                finalpaymentresult = Double.parseDouble((paymentamount));
                                                finalresult = (((0.025) * finalpaymentresult) + finalpaymentresult);
                                                totalpayment.setText(String.valueOf(finalresult));


                                            } catch (NumberFormatException e) {
                                                finalpaymentresult = 0;

                                            }


                                        }
                                    });


                                }
                            }
                    );

                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();


                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                } else {
                    check.setVisibility(View.VISIBLE);
                    credit.setVisibility(View.GONE);
//                    linearLayout.setVisibility(View.GONE);
//                    linearLayout2.setVisibility(View.VISIBLE);
//
//                    btncreditcard.setVisibility(View.GONE);
//                    btnecheck.setVisibility(View.VISIBLE);
//                    textviewlayout.setVisibility(View.GONE);
//                    discovercardlayout.setVisibility(View.GONE);
//                    authorizelayout.setVisibility(View.GONE);
//
//                    //echeck conditions for image
//
//                    echeckauthorizelayout.setVisibility(View.VISIBLE);
//                    echeckdiscoverelayout.setVisibility(View.VISIBLE);
//                    echecktextlayout.setVisibility(View.VISIBLE);

                }
            }
        });


        return rootview;
    }

    private void initialize(View view) {
        cardNumberView = (EditText) view.findViewById(R.id.txtcreaditcardnumber);
        //echeckcardNumberView = (EditText) view.findViewById(R.id.txtcreaditcardnumber);
        setUpCreditCardEditText();
        monthView = (EditText) view.findViewById(R.id.txtexpirymonth);
        yearView = (EditText) view.findViewById(R.id.txtexpiryyear);
        cvvView = (EditText) view.findViewById(R.id.txtccv);

        //echeck initialize

        accountNumber = (EditText) view.findViewById(R.id.txtaccountnumber);
        bankName = (EditText) view.findViewById(R.id.txtbankname);
        accountName = (EditText) view.findViewById(R.id.txtaccountname);
        accountType = (EditText) view.findViewById(R.id.txtaccounttype);
        echeckType = (EditText) view.findViewById(R.id.txtechecktype);

        checkoutButton = (Button) view.findViewById(R.id.btncreditcard);
        btnecheck = (Button) view.findViewById(R.id.btnecheck);
        checkoutButton.setOnClickListener(this);
        responseLayout = (RelativeLayout) view.findViewById(R.id.response_layout);
        responseTitle = (TextView) view.findViewById(R.id.encrypted_data_title);
        responseValue = (TextView) view.findViewById(R.id.encrypted_data_view);
    }

    private void setUpCreditCardEditText() {
        cardNumberView.addTextChangedListener(new TextWatcher() {
            private boolean spaceDeleted;

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // check if a space was deleted
                CharSequence charDeleted = s.subSequence(start, start + count);
                spaceDeleted = " ".equals(charDeleted.toString());
            }

            public void afterTextChanged(Editable editable) {
                // disable text watcher
                cardNumberView.removeTextChangedListener(this);

                // record cursor position as setting the text in the textview
                // places the cursor at the end
                int cursorPosition = cardNumberView.getSelectionStart();
                String withSpaces = formatText(editable);
                cardNumberView.setText(withSpaces);
                // set the cursor at the last position + the spaces added since the
                // space are always added before the cursor
                cardNumberView.setSelection(cursorPosition + (withSpaces.length() - editable.length()));

                // if a space was deleted also deleted just move the cursor
                // before the space
                if (spaceDeleted) {
                    cardNumberView.setSelection(cardNumberView.getSelectionStart() - 1);
                    spaceDeleted = false;
                }

                // enable text watcher
                cardNumberView.addTextChangedListener(this);
            }

            private String formatText(CharSequence text) {
                StringBuilder formatted = new StringBuilder();
                int count = 0;
                for (int i = 0; i < text.length(); ++i) {
                    if (Character.isDigit(text.charAt(i))) {
                        if (count % 4 == 0 && count > 0) formatted.append(" ");
                        formatted.append(text.charAt(i));
                        ++count;
                    }
                }
                return formatted.toString();
            }
        });
    }

    @Override
    public void onClick(View v) {

        if (!areFormDetailsValid()) return;
        pd = new ProgressDialog(getActivity());
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
//
//        progressDialog = ProgressDialog.show(getActivity(), this.getString(R.string.progress_title),
//                this.getString(R.string.progress_message), true);
        if (responseLayout.getVisibility() == View.GONE) responseLayout.setVisibility(View.GONE);

        try {
            EncryptTransactionObject transactionObject = prepareTransactionObject();
            apiClient.getTokenWithRequest(transactionObject, this);




        } catch (NullPointerException e) {
            // Handle exception transactionObject or callback is null.
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
            pd.dismiss();
//            if (progressDialog.isShowing()) progressDialog.dismiss();
            e.printStackTrace();
        }


    }

    private EncryptTransactionObject prepareTransactionObject() {
        ClientKeyBasedMerchantAuthentication merchantAuthentication =
                ClientKeyBasedMerchantAuthentication.
                        createMerchantAuthentication(API_LOGIN_ID, CLIENT_KEY);

        // create a transaction object by calling the predefined api for creation
        return TransactionObject.
                createTransactionObject(
                        TransactionType.SDK_TRANSACTION_ENCRYPTION) // type of transaction object
                .cardData(prepareCardDataFromFields()) // card data to get Token
                .merchantAuthentication(merchantAuthentication).build();
    }

    private EncryptTransactionObject prepareTestTransactionObject() {
        ClientKeyBasedMerchantAuthentication merchantAuthentication =
                ClientKeyBasedMerchantAuthentication.
                        createMerchantAuthentication(API_LOGIN_ID, CLIENT_KEY);

        // create a transaction object by calling the predefined api for creation
        return EncryptTransactionObject.
                createTransactionObject(
                        TransactionType.SDK_TRANSACTION_ENCRYPTION) // type of transaction object
                .cardData(prepareTestCardData()) // card data to prepare token
                .merchantAuthentication(merchantAuthentication).build();
    }

    private CardData prepareTestCardData() {
        return new CardData.Builder(CARD_NUMBER, EXPIRATION_MONTH, EXPIRATION_YEAR).cvvCode("")
                .zipCode("")
                .cardHolderName("")
                .build();
    }

    public void hideSoftKeyboard() {
        InputMethodManager keyboard =
                (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (getActivity() != null && getActivity().getCurrentFocus() != null) {
            keyboard.hideSoftInputFromInputMethod(getActivity().getCurrentFocus().getWindowToken(), 0);
        }
    }

    private boolean areFormDetailsValid() {
        cardNumber = cardNumberView.getText().toString().replace(" ", "");
        month = monthView.getText().toString();
        cvv = cvvView.getText().toString();
        year = yearView.getText().toString();
//bikash
        if (isEmptyField()) {
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            Toast.makeText(getActivity(), "Empty fields", Toast.LENGTH_LONG).show();
            return false;
        }
        if (isEmptyField()) {
            abaRoutingNumber.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            Toast.makeText(getActivity(), "Empty fields", Toast.LENGTH_LONG).show();
            return false;
        }
        if (isEmptyField()) {
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            Toast.makeText(getActivity(), "Empty fields", Toast.LENGTH_LONG).show();
            return false;
        }

        year = YEAR_PREFIX + yearView.getText().toString();

        return validateFields();
    }

    private boolean echeckareFormDetailsValid() {
        cardnumberEcheck = btnecheck.getText().toString().replace(" ", "");
        echeckaccountnumber = accountNumber.getText().toString();
        echeckbankname = bankName.getText().toString();
        echeckaccountname = accountName.getText().toString();


        if (echeckisEmptyField()) {
            btnecheck.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            Toast.makeText(getActivity(), "Empty fields", Toast.LENGTH_LONG).show();
            return false;
        }
        if (echeckisEmptyField()) {
            abaRoutingNumber.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            Toast.makeText(getActivity(), "Empty fields", Toast.LENGTH_LONG).show();
            return false;
        }

        //year = YEAR_PREFIX + yearView.getText().toString();

        return EcheckvalidateFields();
    }

    private boolean EcheckvalidateFields() {
        if (cardnumberEcheck.length() < MIN_CARD_NUMBER_LENGTH) {
            //echeckcardNumberView.requestFocus();
            //cardNumberView.setError(getString(R.string.invalid_card_number));
            btnecheck.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            return false;
        }

        return true;
    }


    private boolean validateFields() {
        if (cardNumber.length() < MIN_CARD_NUMBER_LENGTH) {
            cardNumberView.requestFocus();
            cardNumberView.setError(getString(R.string.invalid_card_number));
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            return false;
        }
        int monthNum = Integer.parseInt(month);
        if (monthNum < 1 || monthNum > 12) {
            monthView.requestFocus();
            monthView.setError(getString(R.string.invalid_month));
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            return false;
        }
        if (month.length() < MIN_YEAR_LENGTH) {
            monthView.requestFocus();
            monthView.setError(getString(R.string.two_digit_month));
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            return false;
        }
        if (year.length() < MIN_YEAR_LENGTH) {
            yearView.requestFocus();
            yearView.setError(getString(R.string.invalid_year));
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            return false;
        }
        if (cvv.length() < MIN_CVV_LENGTH) {
            cvvView.requestFocus();
            cvvView.setError(getString(R.string.invalid_cvv));
            checkoutButton.startAnimation(
                    AnimationUtils.loadAnimation(getActivity(), R.anim.shake_error));
            return false;
        }
        return true;
    }


    private boolean isEmptyField() {
        return (cardNumber != null && cardNumber.isEmpty()) || (month != null && month.isEmpty()) || (
                year != null
                        && year.isEmpty()) || (cvv != null && cvv.isEmpty());
    }

    private boolean echeckisEmptyField() {
        return (cardnumberEcheck != null && cardnumberEcheck.isEmpty()) || (echeckaccountnumber != null && echeckaccountnumber.isEmpty()) || (
                echeckbankname != null
                        && echeckbankname.isEmpty()) || (echeckaccountname != null && echeckaccountname.isEmpty());
    }

    private CardData prepareCardDataFromFields() {
        return new CardData.Builder(cardNumber, month, year).cvvCode(cvv) //CVV Code is optional
                .build();
    }

    @Override
    public void onErrorReceived(ErrorTransactionResponse errorResponse) {

        hideSoftKeyboard();
//        if (responseLayout.getVisibility() != View.GONE) responseLayout.setVisibility(View.GONE);
//        if (progressDialog.isShowing()) progressDialog.dismiss();
//        responseTitle.setText(R.string.error);
        Message error = errorResponse.getFirstErrorMessage();
        String errorString = getString(R.string.code) + error.getMessageCode() + "\n" +
                getString(R.string.message) + error.getMessageText();
        Log.d("error",errorString);
        responseValue.setText(errorString);
        final String country = county.getText().toString().trim();
    Log.d("country",country);
        Toast.makeText(getActivity(), "Please Fill the valid data", Toast.LENGTH_LONG).show();
        pd.dismiss();
    }


    @Override
    public void onEncryptionFinished(EncryptTransactionResponse response) {

        hideSoftKeyboard();
        if (responseLayout.getVisibility() != View.GONE) responseLayout.setVisibility(View.GONE);
//        if (progressDialog.isShowing()) progressDialog.dismiss();
        responseTitle.setText(R.string.token);
        responseValue.setText(response.getDataValue());
        saveCreditCardInfo();
        //String data_value = responseValue.getText().toString();

    }

    public void saveCreditCardInfo() {
        final String data_value = responseValue.getText().toString().trim();
        Log.d("Token", data_value);
        final String first_name = firstName.getText().toString().trim();
        final String last_name = lastName.getText().toString().trim();
        final String addresss = address.getText().toString().trim();
        final String cityy = city.getText().toString().trim();
        final String statee = state.getText().toString();
        final String zip = zipCode.getText().toString().trim();
        final String country = county.getText().toString().trim();
        final String amount = totalpayment.getText().toString();
        // final String pay_for=
        final String year = paymentDateYear.getText().toString().trim();
        final String month = paymentDateMonth.getText().toString().trim();
        final String exp_date_month = expiryDateMonth.getText().toString().trim();
        final String exp_date_year = expirydateYear.getText().toString().trim();
        final String card_num = creditCardNumber.getText().toString().trim();
        final String creditno = card_num.substring(card_num.length() - 10);
        // final String type_p=first.getText().toString().trim();
        //final String user_id=first.getText().toString().trim();
        //final String email=first.getText().toString().trim();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.USERINFO,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.dismiss();
                        Log.d(TAG, response);
                        // Toast.makeText(getActivity(),response,Toast.LENGTH_SHORT).show();
                        try {

                            JSONObject jobj = new JSONObject(response);
                            Log.d(TAG, jobj.toString());
                            String msg = jobj.getString("Message");
                            Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
                            Boolean suc=jobj.getBoolean("Success");
                            if(suc.equals(true)){
                                Intent intent=new Intent(getActivity(),MainActivity3.class);
                                startActivity(intent);
                            }
                            JSONObject data = jobj.getJSONObject("data");
                            JSONObject jsonObject = data.getJSONObject("payment_info");
                        } catch (JSONException e) {
                            pd.dismiss();
                            e.printStackTrace();

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();

                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(DATA_VALUE, data_value);
                Log.d("token", data_value);
                params.put(FIRSTNAME, first_name);
                params.put(LASTNAME, last_name);
                params.put(ADDRESS, addresss);
                params.put(CITY, cityy);
                params.put(STATE, statee);
                params.put(ZIP, zip);
                params.put(COUNTRY, country);
                Log.d("country",country);
                params.put(AMOUNT, amount);
                params.put(YEAR, year);
                params.put(MONTH, month);
                params.put(EXP_DATE_MONTH, exp_date_month);
                params.put(EXP_DATE_YEAR, exp_date_year);
                Log.d("expire year", exp_date_year);
                params.put(CARD_NUM, card_num);
                Log.d(TAG, card_num);
                //  params.put(ECHECKTYPE,onesp);
                // Log.d(TAG,onesp);
                params.put(TYPE_P, "creditcard");
                params.put(Config.USER_ID, String.valueOf(snm.getUser()));
                params.put(PAY_FOR, "Pay Rent");


                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
//        pd=new ProgressDialog(getActivity());
//        pd.setMessage("loading.");
//        pd.setCancelable(false);
//        pd.show();
    }

    public void saveEcheckCardInfo() {


        final String amount = paymentAmount.getText().toString();
        // final String data_value=responseValue.getText().toString().trim();
        final String year = paymentDateYear.getText().toString().trim();
        final String month = paymentDateMonth.getText().toString().trim();

        final String echeckabaroutingnumber = abaRoutingNumber.getText().toString().trim();
        final String echeckaccountnumber = accountNumber.getText().toString().trim();
        final String echeckbankname = bankName.getText().toString().trim();
        final String echeckbankaccountname = accountName.getText().toString().trim();
        // final String echeckaccounttype=accounttype.getSelectedItem().toString().trim();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.USERINFO,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.dismiss();
                        Log.d(TAG, response);
                        try {

                            JSONObject jobj = new JSONObject(response);
                            Log.d(TAG, jobj.toString());
                            String msg = jobj.getString("Message");
                            Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
                            Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
                            Boolean suc=jobj.getBoolean("Success");
                            if(suc.equals(true)){
                                Intent intent=new Intent(getActivity(),MainActivity3.class);
                                startActivity(intent);
                            }
                        } catch (JSONException e) {
                            pd.dismiss();
                            e.printStackTrace();

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.dismiss();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();

                headers.put("Authorization", "Basic YWRtaW46MTIzNA==");
                return headers;
            }

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AMOUNT, amount);
                params.put(PAY_FOR, "Pay Rent");
                params.put(MONTH, month);
                params.put(YEAR, year);
                params.put(TYPE_P, "echeck");

                params.put(Config.USER_ID, String.valueOf(snm.getUser()));
                params.put(ABA_ROUTING_NUMBER, echeckabaroutingnumber);
                params.put(ECHECK_ACCOUNT_NUMBER, echeckaccountnumber);
                params.put(BANK_NAME, echeckbankname);
                params.put(ECHECK_ACCOUNT_NAME, echeckbankaccountname);
                params.put(ACCOUNT_TYPE, twosp);
                Log.d("checktype", onesp);
                params.put(ECHECK_TYPE, onesp);
                Log.d("accounttype", twosp);


                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
        pd = new ProgressDialog(getActivity());
        pd.setMessage("loading.");
        pd.setCancelable(false);
        pd.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        onesp = checktype.getSelectedItem().toString();
        twosp = accounttype.getSelectedItem().toString();
        Log.d(TAG, onesp);
        Log.d("ACCOUTNKSP", twosp);

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

//    public void openDialogPublicPrivateRoom(){
//        Dialouge_CreditCard dppr = new Dialouge_CreditCard();
//        dppr.show(getActivity().getSupportFragmentManager(),"mmtag");
//            }

}


