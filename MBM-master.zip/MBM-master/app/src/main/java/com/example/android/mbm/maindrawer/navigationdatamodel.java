package com.example.android.mbm.maindrawer;

/**
 * Created by Allan on 2017-05-25.
 */

public class navigationdatamodel {
    public int icon;
    public String name;

    // Constructor.
    public navigationdatamodel( String name) {
        this.name = name;
    }
}
