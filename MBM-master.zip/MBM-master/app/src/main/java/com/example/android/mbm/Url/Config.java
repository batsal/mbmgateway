package com.example.android.mbm.Url;

/**
 * Created by Allan on 2017-06-16.
 */

public class Config {
    public static final String baseUrl = "https://mbmmgt.com/mbm-rest/index.php/api/";
    public static final String OPENREGISTER = baseUrl + "User/registration";
    public static final String PAYMENT_URL = baseUrl + "Payment";
    public static final String PAYMENT_CHECK = baseUrl + "Payment/pay";
    public static final String DATA_URL = baseUrl + "Maintenance";
    public static final String RM = baseUrl + "Maintenance/reportIssue";
    public static final String USERINFO = baseUrl + "Payment/pay";
    public static final String DOCUMENTS = baseUrl + "Documents";
    public static final String PROFILE= baseUrl + "User/editInfo";

    //Tags used in the JSON String
    public static final String USER_ID = "user_id";
    public static final String ID = "id";
    public static final String CATEGORIES = "category";
    public static final String TICKET_CATEGORIES = "tickets_categories";
    public static final String FORGOT_PASS = baseUrl + "User/resetPassword";
    public static final String LOGOUT= baseUrl + "Logout";
    public static final String NOTIFICATION= baseUrl + "Notification";

    //JSON array name

}


